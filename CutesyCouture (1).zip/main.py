import tkinter as tk
from tkinter import *
from PIL import ImageTk, Image

win = tk.Tk()
win.title("Cutsey Cotoure!")
win.geometry("630x720")
win.configure(bg="#9EB5FF")  # colors

# Lists and variables
productNames = ["Stickeys", "Pastel Stickeys", "Mechanical Pencils", "Muji Pens", "Pencil Case", "Planner"]
productPrice = [3.5, 3.0, 6.0, 10, 6.0, 5.0]
ID = 0
wishListNames = []
wishListItems = []
itemButtons = []
cart = []
images = []

total = 0.0
counter = 0
counter2 = 0
counter3 = 0
counter4 = 0
counter5 = 0
counter6 = 0
username = ["",""]
password = ["", ""]

newlabel = []
wishlabel = []
totalLbl = tk.Label()
randbool = False

admnuser = "123"
admnpass = "123"
adm1 = False
adm2 = False
usrmode = True


# UNIVERSAL FUNCTIONS

def to_items():
  global adm1
  global adm2

  itemframe.pack(fill='both', expand=1)

  checkoutFrame.forget()
  loginframe.forget()
  wishlistFrame.forget()
  adminframe.forget()
  if adm1 and adm2:
    adminbtnitems.configure(state = NORMAL)
  payBtn.configure(state  = DISABLED)


# opens checkout window
def to_checkout():
  global totalLbl
  
  checkoutFrame.pack(fill='both', expand=1)

  totalLbl.configure(state=NORMAL, font=("Arial", 10))
  itemframe.forget()
  loginframe.forget()
  wishlistFrame.forget()
  adminframe.forget()
   

# opens wishlist window
def to_wishlist():
  wishlistFrame.pack(fill = 'both', expand = 1)

  itemframe.forget()
  loginframe.forget()
  checkoutFrame.forget()
  adminframe.forget()
    
def toAdmin():
  adminframe.pack(fill = 'both', expand = 1)

  itemframe.forget()
  loginframe.forget()
  checkoutFrame.forget()
  wishlistFrame.forget()

  passBtn.configure(state = DISABLED)
  userBtn.configure(state = DISABLED)


# logout
def logout():
    loginframe.pack(pady = 50)
    loginBtn.configure(state=DISABLED)

   
    passwrdBtn.configure(state=DISABLED)
    checkoutFrame.forget()
    itemframe.forget()
    wishlistFrame.forget()
    adminframe.forget()
    adminbtnitems.configure(state = DISABLED)
    usernameEnt.delete(0,END)


# adds an item to the cart
def add_item(num):
    global total
    global productPrice
    global counter2
    global newlabel
    global totalLbl

    if len(cart)==0:
        counter2 = 0

    if productNames[num] in cart:
        cart == cart
    else:
        total = total + productPrice[num]
        cart.append(productNames[num])
        # create new label
        newlabel.append(
            tk.Label(checkoutFrameBill, text=f"{productNames[num]} - ${productPrice[num]}", fg="black", bg="#dcedc1",font=("Arial", 8), anchor="w", justify=LEFT))
        newlabel[counter2].grid(sticky=W, column=0, row=counter2 + 1, padx =15)
        counter2 += 1
        totalLbl.destroy()
        totalLbl = tk.Label(checkoutFrameBill, text=f"Your total is ${total}", bg="#dcedc1", font=("Arial", 8), anchor="w", justify=LEFT)
        totalLbl.grid(sticky=W, column=0, row=counter2 + 1, padx = 15)



# adds an item to wishlist
def like_item(num):
    global wishlabel
    global images
    global counter3
    global counter4
    global wishListItems
    global wishListNames


    lengthWL =len(wishListItems)
    if lengthWL == 0:
        counter3 = 0
        counter4 = 0
        wishListItems.clear()
        wishListNames.clear()
        
    if productNames[num] in wishListNames:
        wishListItems == wishListItems
    else:
        wishListNames.append(productNames[num])
        if counter4<3:

            wishListItems.append(tk.Label(wlItemsFrame, image=images[num], padx=0, pady=10))
            

            wishListItems[counter4].grid(column = 0, row = counter3, padx = 10, pady = 10)
            counter3 += 1


            wishlabel.append(tk.Label(wlItemsFrame, text=f"{productNames[num]} - ${productPrice[num]}", fg="black", bg="#dcedc1",font=("Arial", 8), anchor="w", justify=LEFT))

            
            wishlabel[counter4].grid(column = 0, row = counter3, padx = 10)

            counter3+=1
            counter4 += 1


        else:

            wishListItems.append(tk.Label(wlItemsFrame, image=images[num], padx=0, pady=15))
            wishListItems[counter4].grid(column = 1, row =counter3 - 6)
            counter3 += 1

            wishlabel.append(tk.Label(wlItemsFrame, text=f"{productNames[num]} - ${productPrice[num]}", fg="black", bg="#dcedc1",font=("Arial", 8), anchor="w", justify=LEFT))
            wishlabel[counter4].grid(column = 1, row = counter3-6)
            counter3 += 1
            counter4 += 1




# LOGIN FRAME AND ALL ITS COMPONENTS
loginframe = tk.Frame(win, width=630, height=700, bg="#BBD1FE", padx=15, pady=15)
loginframe.pack(padx=10, pady=40)
greeting = tk.Label(loginframe, text="")

loginlbl = tk.Label(loginframe,text="Welcome to Cutesy Couture! Make a name and password to start!\n If you're an admin, please enter your admin credentials.", font = ("Arial",10 ), bg = "#D7EDFF")
loginlbl.grid(column=0, row=0, columnspan=3)


# login specific functions

def enteruser():
    global username
    global adm1
    global admnuser
    global counter6
    global greeting

    username[1] = usernameEnt.get()

    if username[1] == admnuser:
      adm1 = True
      
      username[0] = usernameEnt.get()
 
      userName = "Username logged!"
      greeting.configure(text=userName, bg = "#BBD1FF", font = ("Arial",9 ))
      greeting.grid(column=0, row=2)
      passwrdBtn.configure(state=NORMAL)
      counter6+=1

    elif counter == 0 and not username[1] ==admnuser:
      username[0] = usernameEnt.get()
      userName = "Username logged!"
      adm1 = False
      greeting.configure(text=userName,bg = "#BBD1FF", font = ("Arial",9))
      greeting.grid(column=0, row=2)
      passwrdBtn.configure(state=NORMAL)
      counter6 +=1
    else:

      if username[1] == username[0]:
        greeting.configure(text=" Username Correct!",bg = "#BBD1FF", font = ("Arial",9))
        greeting.grid(column=0, row=2)
        passwrdBtn.configure(state = NORMAL)
        usernameEnt.delete(0, END)
        counter6 +=1

      else:
        greeting.configure(text="Incorrect Username.",bg = "#BBD1FF", font = ("Arial",9))
        passwrdBtn.configure(state=DISABLED)
        greeting.grid(column=0, row=2)
        usernameEnt.delete(0, END)
        counter6 +=1


def enterpass():
    global password
    global adm2
    global counter
    global usrmode

    password[1] = passwrdEnt.get()

    if password[1] == admnpass:
        adm2 = True

        passwrdEnt.delete(0, END)
        password[0] = passwrdEnt.get()
        greeting = tk.Label(loginframe, text="Password logged!",bg = "#BBD1FF", font = ("Arial",9))
        greeting.grid(column=0, row=4)
        loginBtn.configure(state=NORMAL)
        counter +=1
    elif counter == 0:
        adm2 = False

        password[0] = passwrdEnt.get()
  
        greeting = tk.Label(loginframe, text="Password logged!",bg = "#BBD1FF", font = ("Arial",9))
        greeting.grid(column=0, row=4)
        loginBtn.configure(state=NORMAL)
        counter +=1

        passwrdEnt.delete(0, END)

    elif counter > 0 and usrmode == True:
        adm2 = False

        if password[1] == password[0]:
            greeting = tk.Label(loginframe, text=" Password Correct!",bg = "#BBD1FF", font = ("Arial",9))
            greeting.grid(column=0, row = 4)
            loginBtn.configure(state=NORMAL)
            passwrdEnt.delete(0, END)
            counter +=1
        else:

            greeting = tk.Label(loginframe, text="Incorrect Password.",bg = "#BBD1FF", font = ("Arial",9))
            greeting.grid(column=0, row = 4)
            loginBtn.configure(state=DISABLED)
            passwrdEnt.delete(0, END)
            counter +=1


# username set up
usernamelbl = tk.Label(loginframe, text="Username:", bg = "#D7EDFF", font = ("Arial", 9))
usernamelbl.grid(column=0, row=1)

usernameEnt = tk.Entry(loginframe, width=20, state=NORMAL)
usernameEnt.grid(column=1, row=1)

usernameBtn = tk.Button(loginframe, text="ENTER", command=enteruser,bg = "#D7EDFF", font = ("Arial",9 ))
usernameBtn.grid(column=2, row= 1)

# password set up
passwrdlbl = tk.Label(loginframe, text="Password:", bg = "#D7EDFF", font = ("Arial", 9))
passwrdlbl.grid(column=0, row=3)

passwrdEnt = tk.Entry(loginframe, width=20)
passwrdEnt.grid(column=1, row=3)

passwrdBtn = tk.Button(loginframe, text="ENTER", command=enterpass, state = DISABLED, bg = "#D7EDFF", font = ("Arial", 9))
passwrdBtn.grid(column=2, row=3)

loginBtn = tk.Button(loginframe, text="LOGIN", state=DISABLED, command=to_items, bg = "#D7EDFF")
loginBtn.grid(column=1, row=5, columnspan=2)


# ITEM FRAME AND ALL ITS COMPONENTS
itemframe = tk.Frame(win, width=630, height=700, bg="#d2e7ff", padx =10, pady=15)

# Top Label
label = tk.Label(itemframe, text="Click on an item to add it to your cart!", bg = "#fffef9", font =("Arial", 9))
label.grid(column=1, row=0, pady=15)

# BUTTONS
toCheckout = tk.Button(itemframe, text="Go to Checkout", command=to_checkout, bg="#fff6e9", font = ("Arial",9 ))
toCheckout.grid(column=0, row=1, pady=15, columnspan=2)
toWishList = tk.Button(itemframe, text="Go to Wishlist", command=to_wishlist, bg="#fff6e9", font = ("Arial", 9))
toWishList.grid(column=1, row=1, pady=15, columnspan=2)

logout = tk.Button(itemframe, text="LOGOUT", command=logout, bg = "#fff6e9", fg = "#031B13", font = ("Arial",9 ))
logout.grid(column=2, row=0, pady=15)

adminbtnitems = tk.Button(itemframe, text = "ADMIN PAGE", bg = "#fff6e9", command = toAdmin,state =  DISABLED, font = ("Arial",9 ))
adminbtnitems.grid(column = 1, row = 8, pady =20)



# INITIALIZING IMAGES

# first stickeys (image 1)
stickeys = Image.open("Assets/stickeys.jpg")
resized_image = stickeys.resize((150, 150), Image.ANTIALIAS)
stickeys = ImageTk.PhotoImage(resized_image)
images.append(stickeys)

# second stickeys (image 2)
stickeys2 = Image.open("Assets/stickeys2.jpg")
resized_image = stickeys2.resize((150, 150), Image.ANTIALIAS)
stickeys2 = ImageTk.PhotoImage(resized_image)
images.append(stickeys2)

# mechanical pencils (image 3)
mech_pen = Image.open("Assets/mechanicalpencils.jpg")
resized_image = mech_pen.resize((150, 150), Image.ANTIALIAS)
mech_pen = ImageTk.PhotoImage(resized_image)
images.append(mech_pen)

# muji_pens (image_4)
muji_pens = Image.open("Assets/mujipens.jpg")
resized_image = muji_pens.resize((150, 150), Image.ANTIALIAS)
muji_pens = ImageTk.PhotoImage(resized_image)
images.append(muji_pens)

# pencil_case (image 5)
pencil_case = Image.open("Assets/pencilcase.jpg")
resized_image = pencil_case.resize((150, 150), Image.ANTIALIAS)
pencil_case = ImageTk.PhotoImage(resized_image)
images.append(pencil_case)

# planner (image 6)
planner = Image.open("Assets/planner.jpg")
resized_image = planner.resize((150, 150), Image.ANTIALIAS)
planner = ImageTk.PhotoImage(resized_image)
images.append(planner)

#basic format incase you want to add another image
# stickeys  = Image.open("Assets/stickeys.jpg")
# resized_image= stickeys.resize((150,150), #Image.ANTIALIAS)
# stickeys = ImageTk.PhotoImage(resized_image)

# PLACING

# IMAGES - ROW 1
stickeys = tk.Label(itemframe, image=stickeys, padx=0, pady=15)
stickeys.grid(column=0, row=2)

stickeys2 = tk.Label(itemframe, image=stickeys2, padx=0, pady=15)
stickeys2.grid(column=1, row=2)

mech_pen = tk.Label(itemframe, image=mech_pen, pady=15, justify = LEFT)
mech_pen.grid(column=2, row=2)


# PRICE BUTTONS
stickeysPrice = tk.Button(itemframe, text=str(productNames[0]) + ": $" + str(productPrice[0]),command=lambda: add_item(0), bg ="#fff6e9", font=("Arial", 8))
itemButtons.append(stickeysPrice)
stickeysPrice.grid(column=0, row=3)


stickeys2Price = tk.Button(itemframe, text=str(productNames[1]) + ": $" + str(productPrice[1]),command=lambda: add_item(1),bg ="#fff6e9", font=("Arial",8))
stickeys2Price.grid(column=1, row=3)
itemButtons.append(stickeys2Price)

mech_penPrice = tk.Button(itemframe, text=str(productNames[2]) + ": $" + str(productPrice[2]),command=lambda: add_item(2), font=("Arial", 8), bg ="#fff6e9")
mech_penPrice.grid(column=2, row=3)
itemButtons.append(mech_penPrice)

# LIKE BUTTONS -  ROW 1

likeButton1 = tk.Button(itemframe, text="Add To Wishlist", command=lambda: like_item(0), bg="#ffefd7", font=("Arial", 8))
likeButton1.grid(column=0, row=4, pady =5)

likeButton2 = tk.Button(itemframe, text="Add To Wishlist", command=lambda: like_item(1), bg="#ffefd7", font=("Arial", 8))
likeButton2.grid(column=1, row=4, pady =5)

likeButton3 = tk.Button(itemframe, text="Add To Wishlist", command=lambda: like_item(2), bg="#ffefd7", font=("Arial", 8))
likeButton3.grid(column=2, row=4, pady =5)

# IMAGES -  ROW 2
muji_pens = tk.Label(itemframe, image=muji_pens, padx=0, pady=15)
muji_pens.grid(column=0, row=5)

pencil_case = tk.Label(itemframe, image=pencil_case, padx=0, pady=15)
pencil_case.grid(column=1, row=5)

planner = tk.Label(itemframe, image=planner, padx=0, pady=15)
planner.grid(column=2, row=5)


# PRICES (change names)
mujiPrice = tk.Button(itemframe, text=str(productNames[3]) + ": $" + str(productPrice[3]), command=lambda: add_item(3),bg ="#fff6e9", font=("Arial", 8))
mujiPrice.grid(column=0, row=6)
itemButtons.append(mujiPrice)

pencil_casePrice = tk.Button(itemframe, text=str(productNames[4]) + ": $" + str(productPrice[4]), command=lambda: add_item(4), bg ="#fff6e9", font=("Arial",8))
pencil_casePrice.grid(column=1, row=6)
itemButtons.append(pencil_case)

plannerPrice = tk.Button(itemframe, text=str(productNames[5]) + ": $" + str(productPrice[5]),command=lambda: add_item(5), bg ="#fff6e9", font=("Arial", 8))
plannerPrice.grid(column=2, row=6)
itemButtons.append(plannerPrice)

# LIkE BUTTONS -  ROW 2

likeButton4 = tk.Button(itemframe, text="Add To Wishlist", command=lambda: like_item(3), bg="#ffefd7", font=("Arial", 8))
likeButton4.grid(column=0, row=7, pady =5)

likeButton5 = tk.Button(itemframe, text="Add To Wishlist", command=lambda: like_item(4), bg="#ffefd7", font=("Arial", 8))
likeButton5.grid(column=1, row=7, pady =5)

likeButton6 = tk.Button(itemframe, text="Add To Wishlist", command=lambda: like_item(5), bg="#ffefd7", font=("Arial", 8))
likeButton6.grid(column=2, row=7, pady =5)

# WISHLIST FRAME AND ALL ITS COMPONENTS

# CHECKOUT FRAME AND ALL ITS COMPONENTS

checkoutFrame = tk.Frame(win, width=700, height=700, padx=5, pady=5, bg="#a8e6cf")

checkoutFrameBill = tk.Frame(checkoutFrame, width=300, height=500, bg="#dcedc1")
checkoutFrameBill.grid_propagate(0)
checkoutFrameBill.grid(column=0, row=1, padx=3, pady=10)

checkoutFramePswrd = tk.Frame(checkoutFrame, width=300, height=500, bg="#dcedc1", padx= 10)
checkoutFramePswrd.grid_propagate(0)
checkoutFramePswrd.grid(column=1, row=1, padx=3, pady=10)

checkoutFrameRmv = tk.Frame(checkoutFrame, width=580, height=130, bg="#dcedc1", padx=50)
checkoutFrameRmv.grid_propagate(0)
checkoutFrameRmv.grid(column=0, row=2, columnspan=2, pady=10)

#checkout specific functions

def payout():
    global cart
    global newlabel
    global productPrice
    global productNames
    global totalLbl
    global total

    cartlength = len(cart)
    randbool = True

    if cartlength >= 0:
        for i in range(cartlength):
            total = 0.0

            cart.clear()
            newlabel[i].destroy()

            totalLbl.destroy()

            totalLbl = tk.Label(checkoutFrameBill, text=f"Your total is ${total}", bg="#dcedc1",font=('Arial', 9), anchor="w", justify=LEFT)

            totalLbl.grid(column=0, row=cartlength + 1)

            greetAgain = tk.Label(checkoutFramePswrd, text="Order Complete!", bg="#ffd3b6")
            greetAgain.grid(column=0, row=6, columnspan = 2)

    if randbool:
        newlabel.clear()


def pswrd_verification():
    global password

    enteredpassword = enterPass.get()

    if password[1] == enteredpassword:
        checkgreeting = tk.Label(checkoutFramePswrd, text=" Password Correct,\n Click pay to complete the transaction!", bg = "#ffd3b6")
        checkgreeting.grid(column=0, row=2, columnspan = 2)
        payBtn.configure(state = NORMAL)
        enterPass.delete(0, END)
    else:
        checkgreeting = tk.Label(loginframe, text="Incorrect Password. Please try again", bg = "#ffd3b6")
        checkgreeting.grid(column=0, row=2)
        enterPass.delete(0, END)


def remove():
    global cart
    global newlabel
    global productPrice
    global productNames
    global totalLbl
    global total
    global counter5 

    itemToRemove = rmvItem.get()
    cartlength = len(cart)
    
   

    if cartlength > 0:
        for i in range(cartlength):
            if itemToRemove == cart[i]:
                index = productNames.index(cart[i])
                total = total - productPrice[index]

                newlabel[i].destroy()
                cart.remove(itemToRemove)
                newlabel.remove(newlabel[i])
                

                totalLbl.destroy()
                totalLbl = tk.Label(checkoutFrameBill, text=f"Your total is ${total}", bg="#dcedc1", state=NORMAL, font = ('Arial',9))
                totalLbl.grid(column=0, row=cartlength + 1)

# display

bill = tk.Label(checkoutFrameBill, text="BILL", bg="#dcedc1", fg="white", font=("helvetica", 30),padx=50)
bill.grid(column=0, row=0, padx=40)

removelbl = tk.Label(checkoutFrameRmv, text="Enter the Item you would like to remove :(", bg="#dcedc1", font = ("Arial",9))
removelbl.grid(column=0, row=0, columnspan=3, )

enterLbl = tk.Label(checkoutFrameRmv, text="Enter Item:", bg="#dcedc1", font = ("Arial",9))
enterLbl.grid(column=0, row=1,)

rmvItem = tk.Entry(checkoutFrameRmv,justify=CENTER)
rmvItem.grid(column=1, row=1, )

rmvBtn = tk.Button(checkoutFrameRmv, text="REMOVE",  bg="#ffd3b6", command=remove, font = ("Arial",9))
rmvBtn.grid(column=2, row=1 )

toItems = tk.Button(checkoutFrameRmv, text="To Items",  bg="#ffd3b6", command=to_items, font = ("Arial",9))
toItems.grid(column=0, row=4, columnspan = 2, padx = 50)

toWishList = tk.Button(checkoutFrameRmv, text="To Wishlist", bg="#ffd3b6", command=to_wishlist, font = ("Arial",9))
toWishList.grid(column=1, row=4, columnspan  =2, padx = 50)

enterPassLbl = tk.Label(checkoutFramePswrd, text = "Please Enter your Password to confirm \nthe transanction!", bg = "#dcedc1", font = ("Arial",9))
enterPassLbl.grid(column =0, row =0, pady=20 , columnspan = 2)

enterPass = tk.Entry(checkoutFramePswrd, width = 20)
enterPass.grid(column = 0, row =1 )

enterBtn =  tk.Button(checkoutFramePswrd, text = "ENTER", bg = "#ffd3b6", command = pswrd_verification, font = ("Arial",9))
enterBtn.grid(column= 1, row = 1)

payBtn = tk.Button(checkoutFramePswrd, text = "Pay!", bg = "#ffd3b6", command  = payout, state =  DISABLED, font = ("Arial",9))
payBtn.grid(column = 0, row = 3, columnspan= 2)

#logout2 = tk.Button(checkoutFrameRmv, text="LOGOUT", bg="#ff8b94", command=logout) #state = NORMAL)
#logout2.grid(column=2, row=4)

# WISHLIST FRAME AND ITS COMPONENTS

#WISHLIST SPECIFIC FUNCTIONS

def removewl():
    global wishlabel
    global wishListItems
    global productNames
    global wishListNames
    global counter3
    global counter4


    itemToRemove = rmvItemWL.get()
    wishLen = len(wishListItems)


    if wishLen>0:
        for i in range(wishLen):
            if itemToRemove == wishListNames[i]:

                #removing the image
                wishListItems[i].destroy()
                wishListNames.remove(itemToRemove)
                wishListItems.remove(wishListItems[i])

                counter3 -=1 
                counter4 -=1
                #removing the label
                wishlabel[i].destroy()
                wishlabel.remove(wishlabel[i]) 
                counter3-=1
                
                

    if wishLen == 0:
        wishListItems.clear()
        wishListNames.clear()
        wishlabel.clear()
        nomore = tk.Label(wlRmvFrame, text="There are no more items left to remove!")
        nomore.grid(column=1, row=3, columnspan=2)

wishlistFrame = tk.Frame(win, width=700, height=700, padx=5, pady=5, bg="#a8e6cf")

wlToCheckout = tk.Button(wishlistFrame,text = "Checkout", command = to_checkout, bg ="#ffd3b6", font = ("Arial",9))
wlToCheckout.grid(column = 0, row = 0)

wlToItems = tk.Button(wishlistFrame, text = "Items", command = to_items, bg ="#ffd3b6", font = ("Arial",9))
wlToItems.grid(column = 1, row = 0)

wlItemsFrame = tk.Frame(wishlistFrame, width = 610, height = 590, bg = "#dcedc1")
wlItemsFrame.grid_propagate(0)
wlItemsFrame.grid(column = 0, row = 1, columnspan = 2, pady = 5)

wlRmvFrame = tk.Frame(wishlistFrame, width = 610, height = 100, bg = "#dcedc1")
wlRmvFrame.grid_propagate(0)
wlRmvFrame.grid(column = 0, row = 2, columnspan = 2, pady = 5)

wlRemoveLbl = tk.Label(wlRmvFrame, text="Enter the Item you would like to remove from your wishlist", bg="#dcedc1",justify=CENTER, font = ("Arial",9))
wlRemoveLbl.grid(column=0, row=0, columnspan=3)

enterLblWL = tk.Label(wlRmvFrame, text="Enter Item:", bg="#dcedc1", font = ("Arial",9))
enterLblWL.grid(column=0, row=1)

rmvItemWL = tk.Entry(wlRmvFrame,justify=CENTER)
rmvItemWL.grid(column=1, row=1)

rmvBtnWL = tk.Button(wlRmvFrame, text="REMOVE",  bg="#ffd3b6", command=removewl, font = ("Arial",9))
rmvBtnWL.grid(column=2, row=1)

#wlLogout = tk.Button(wishlistFrame, text = "LOGOUT", command = logout)
#wlLogout.grid(column = 2, row = 0) 

#ADMIN FRAME AND ITS COMPONENTS

#admin specific fucntions

def enterFirst():
  global productNames
  global ID
  
  
  productLen =len(productNames)
  nametoChange = enterInitName.get()

  for i in range(productLen):
    if productNames[i] == nametoChange:
      ID = i
      enterInitName.delete(0, END)
      enterBtnFin.configure(state = NORMAL)
      enterFinName.delete(0,END)



def enterScd(num):
  global productNames
  global ID
  global itemButtons

  if num == 1:
    newName = enterFinName.get()

    productNames[ID] = newName
    enterFinName.delete(0, END)
    itemButtons[ID].configure(text = str(productNames[ID]) + ": $" + str(productPrice[ID]))
    enterBtnFin.configure(state = DISABLED)
  else:
    newPrice = enterFinPrice.get()

    productPrice[ID] = newPrice
    enterFinPrice.delete(0, END)
    itemButtons[ID].configure(text = str(productNames[ID]) + ": $" + str(productPrice[ID]))
    enterPrice.delete(0,END)
    enterBtnFin2.configure(state = DISABLED)

  ID = 0
      


def enterNm():
  global productNames
  global ID
  
  productLen =len(productNames)
  pricetoChange = enterPrice.get()

  for i in range(productLen):
    if productNames[i] == pricetoChange:
      ID = i
      enterPrice.delete(0, END)
      enterBtnFin2.configure(state = NORMAL)
      enterFinPrice.delete(0,END)


def currentPass():
    global admnpass

    ogPass = ogPassEntry.get()

    if admnpass == ogPass:
        ogPassEntry.delete(0,END)
        passBtn.configure(state = NORMAL)
        userBtn.configure(state = NORMAL)


def newCred(num):
    global admnuser
    global admnpass
    if num == 1:
        admnuser = userEntry.get()
    else:
        admnpass = passEntry.get()

    passEntry.delete(0,END)
    userEntry.delete(0,END)
        


adminframe = tk.Frame(win, width=700, height=700, padx=5, pady=5, bg="#382d72")


nameChangeFrame = tk.Frame(adminframe, width=580, height=180, bg="#c0b1f4")
nameChangeFrame.grid_propagate(0)
nameChangeFrame.grid(row=1, column=0, pady=10, padx=20)

priceChangeFrame = tk.Frame(adminframe, width=580, height=180, bg="#c0b1f4")
priceChangeFrame.grid_propagate(0)
priceChangeFrame.grid(row=2, column=0, pady=10, padx=20)

infoChangeFrame = tk.Frame(adminframe, width=580, height=180, bg="#c0b1f4")
infoChangeFrame.grid_propagate(0)
infoChangeFrame.grid(row=3, column=0, pady=10, padx=20)

toItemsAdmin = tk.Button(adminframe, text="Items", command=to_items, bg="#CCCCFF", font = ("Arial",8 ))
toItemsAdmin.grid(row=0, column=0, columnspan=3)

# NAME CHANGE FRAME
namechangeLbl = tk.Label(nameChangeFrame, text="Enter the name of the item you would like to change\n then enter the name you would like to change it to.", bg="#CCCCFF", font = ("Arial",9))
namechangeLbl.grid(column=0, row=0, columnspan=3, padx = 100)

enterLbl1 = tk.Label(nameChangeFrame, text="Enter Product Name:",bg="#CCCCFF", font = ("Arial",9))
enterLbl1.grid(column=0, row=1, )

enterInitName = tk.Entry(nameChangeFrame)
enterInitName.grid(column=1, row=1)

enterBtnInit = tk.Button(nameChangeFrame, text="ENTER", command=enterFirst, bg = "#683BAB", fg = "white", font = ("Arial",9))
enterBtnInit.grid(column=2, row=1)

enterLbl2 = tk.Label(nameChangeFrame, text="Enter New Name:",bg="#CCCCFF", font = ("Arial",9))
enterLbl2.grid(column=0, row=2)

enterFinName = tk.Entry(nameChangeFrame)
enterFinName.grid(column=1, row=2)

enterBtnFin = tk.Button(nameChangeFrame, text="ENTER", command=lambda: enterScd(1), state=DISABLED, bg = "#683BAB", fg = "white", font = ("Arial",8))
enterBtnFin.grid(column=2, row=2)

# PRICE CHANGE FRAME
pricechangeLbl = tk.Label(priceChangeFrame, text="Enter the name of the item you would like to change\n then enter the price you would like to change it to.", bg="#CCCCFF", font = ("Arial",9))
pricechangeLbl.grid(column=0, row=0, columnspan = 3,padx = 100)

enterLbl3 = tk.Label(priceChangeFrame, text="Enter Product Name:",bg="#CCCCFF", font = ("Arial",9))
enterLbl3.grid(column=0, row=1)

enterPrice = tk.Entry(priceChangeFrame)
enterPrice.grid(column=1, row=1)

enterBtnInit2 = tk.Button(priceChangeFrame, text="ENTER", command=enterNm, bg = "#683BAB", fg = "white", font = ("Arial",9))
enterBtnInit2.grid(column=2, row=1)

enterLbl4 = tk.Label(priceChangeFrame, text="Enter New Price:",bg="#CCCCFF", font = ("Arial",9))
enterLbl4.grid(column=0, row=2)

enterFinPrice = tk.Entry(priceChangeFrame)
enterFinPrice.grid(column=1, row=2)

enterBtnFin2 = tk.Button(priceChangeFrame, text="ENTER", command=lambda: enterScd(2), state=DISABLED, bg = "#683BAB", fg = "white", font = ("Arial",9))
enterBtnFin2.grid(column=2, row=2)

# USERNAME AND PASS CHANGE FRAME

userChangeLbl = tk.Label(infoChangeFrame, text="Enter your password to\nchange the admin login credentials",bg="#CCCCFF", font = ("Arial",9))
userChangeLbl.grid(column=0, row=0, columnspan=3, padx = 100)

ogPassLbl = tk.Label(infoChangeFrame, text="Current Password:", bg="#CCCCFF", font = ("Arial",9))
ogPassLbl.grid(column=0, row=1)

ogPassEntry = tk.Entry(infoChangeFrame)
ogPassEntry.grid(column=1, row=1)

ogPassBtn = tk.Button(infoChangeFrame, text="ENTER", bg="#683BAB", fg = "white", command = currentPass, font = ("Arial",9))
ogPassBtn.grid(column=2, row=1)

userLbl = tk.Label(infoChangeFrame, text="New Username:", bg="#CCCCFF", font = ("Arial",9))
userLbl.grid(column=0, row=2)

userEntry = tk.Entry(infoChangeFrame)
userEntry.grid(column=1, row=2)

userBtn = tk.Button(infoChangeFrame, text="ENTER", bg="#683BAB", fg = "white", state=DISABLED, command = lambda:newCred(1), font = ("Arial",9 ))
userBtn.grid(column=2, row=2)

passLbl = tk.Label(infoChangeFrame, text="New Password:", bg="#CCCCFF", font = ("Arial",9))
passLbl.grid(column=0, row=3)

passEntry = tk.Entry(infoChangeFrame)
passEntry.grid(column=1, row=3)

passBtn = tk.Button(infoChangeFrame, text="ENTER", bg="#683BAB", fg = "white", state=DISABLED, command = lambda:newCred(2), font = ("Arial",9 ))
passBtn.grid(column=2, row=3)

win.mainloop()
